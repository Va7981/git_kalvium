from flask import Flask, request, render_template, jsonify

app = Flask(__name__)

operations_history = []


@app.route('/')
def home():
    return "Welcome to the Math Server!"


@app.route('/history')
def history():
    return render_template('history.html', history=operations_history)


@app.route('/<path:expression>')
def calculate(expression):
    # Separate operations and operands based on slashes
    parts = expression.split('/')

    # Initialize variables for calculation
    current_number = float(parts[0])
    current_operation = None
    question = parts[0]

    for part in parts[1:]:
        if part in ('plus', 'minus', 'into', 'over'):
            current_operation = part
        else:
            if current_operation is None:
                return "Invalid request", 400

            question += f' {current_operation} {part}'
            if current_operation == 'plus':
                current_number += float(part)
            elif current_operation == 'minus':
                current_number -= float(part)
            elif current_operation == 'into':
                current_number *= float(part)
            elif current_operation == 'over':
                current_number /= float(part)
            current_operation = None

    answer = current_number

    operations_history.append((question, answer))
    if len(operations_history) > 20:
        operations_history.pop(0)

    return jsonify(question=question, answer=answer)


if __name__ == '__main__':
    app.run(debug=True)
